//
//  RegisterViewController.h
//  photocopier
//
//  Created by Zhansaya on 03.12.15.
//  Copyright © 2015 Zhansaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController

@end
