//
//  PrintViewController.h
//  photocopier
//
//  Created by Zhansaya on 04.12.15.
//  Copyright © 2015 Zhansaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrintViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property NSMutableArray * array;
@end
