//
//  CopyViewController.h
//  photocopier
//
//  Created by Zhansaya on 04.12.15.
//  Copyright © 2015 Zhansaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CopyViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *krutilka1;

@end
