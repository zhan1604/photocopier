//
//  ViewController.h
//  photocopier
//
//  Created by Zhansaya on 01.12.15.
//  Copyright © 2015 Zhansaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

